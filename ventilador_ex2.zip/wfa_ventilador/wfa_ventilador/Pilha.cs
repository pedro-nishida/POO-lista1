﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfa_ventilador
{
    internal class Pilha
    {
        private Stack<string> pecas;

        public Pilha()
        {
            pecas = new Stack<string>();
        }

        public void Empilhar(string peca)
        {
            pecas.Push(peca);
        }

        public string Desempilhar()
        {
            if (pecas.Count == 0)
            {
                throw new InvalidOperationException("A pilha está vazia.");
            }

            return pecas.Pop();
        }

        public void SubstituirPeca(string pecaVelha, string pecaNova)
        {
            Stack<string> tempStack = new Stack<string>();

            // Retira as peças da pilha até encontrar a peça a ser substituída
            while (pecas.Count > 0)
            {
                string peca = pecas.Pop();

                if (peca == pecaVelha)
                {
                    // Substitui a peça
                    tempStack.Push(pecaNova);
                    break;
                }

                tempStack.Push(peca);
            }

            // Reinserção das peças na pilha
            while (tempStack.Count > 0)
            {
                pecas.Push(tempStack.Pop());
            }
        }

        public void Enumerador()
        {
            foreach (var item in pecas)
            {
                Console.WriteLine(item);
            }
        }

    }
}
