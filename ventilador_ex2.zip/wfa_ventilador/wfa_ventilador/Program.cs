﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfa_ventilador
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pilha ventilador = new Pilha();

            // Empilhar as peças na ordem adequada
            ventilador.Empilhar("Hélice");
            ventilador.Empilhar("Lâmpada");
            ventilador.Empilhar("Cúpula de Vidro");
            
            //mostrar as peças
            ventilador.Enumerador();

            Console.WriteLine("\n------------------------------------");

            // Substituir a lâmpada
            Console.WriteLine("Substituindo a lâmpada...");

            // Simular a substituição da peça: desmonta e guarda as peças até trocar a peça pedida e montar novamente
            ventilador.SubstituirPeca("Lâmpada", "Nova Lâmpada");

            // Mostrar o resultado
            ventilador.Enumerador();

            Console.ReadLine();
        }
    }
}
